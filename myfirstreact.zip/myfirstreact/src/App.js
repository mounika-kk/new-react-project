import React,{ Component } from 'react';


import Header from './components/Header';
import Login from './components/Login';
import Main from './components/Main';


// function App() {
//   const [page, setPage] = useState(0);
//   return (
//     <div >
//       <Navbar setPage={setPage}/>
//       {page ==0 ? <Main setPage={setPage} /> : null}
      
//       {page ==2 ? <ThankYou/> : null}
//     </div>
//   );
// }
// export default App;
class App extends Component {
  render() {
    return (
      <div className="App">
         
         
        <Header />
        
        <Main />
        <Login />

      </div>
    );
  }
}
 export default App;
