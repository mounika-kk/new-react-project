import React, { Component} from 'react';

class Header extends Component {
    render() {
        return (
            <header>
            <div className="Head">
                Trip Maker
            </div>
            <nav>
                <ul>
                    <li className="First">
                        <a href="#">Home</a>
                    </li>
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Places to go</a>
                    </li>
                    <li className="Last">
                        <a href="#">Contact us</a>
                    </li>
                </ul>
            </nav>
            </header>
        );
    }
}
       

export default Header;