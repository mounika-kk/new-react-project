
import React, { Component} from 'react';

class Main extends Component {
    
    render() {
        return (
            <main>
            <div className="home">
            
           <h1> Discover The Word</h1>
            <p> Explore the worlds most incredible places,</p> 
               <p> with the best local guides and hosts </p>
              
               
               </div>
            
            </main>
        );
    }
}
export default Main;