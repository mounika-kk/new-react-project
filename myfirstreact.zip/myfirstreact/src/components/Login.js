import React, { Component} from 'react';

class Login extends Component {
    render() {
        return (
           
            <div className="Login">
                <div className="Login__Aside"></div> 
                <div className="login__Form">
                    <div className="PageSwitcher">
                <a href="#" className="PageSwitcher__Item">Sign In</a>
                <a href="#" className="PageSwitcher__Item PageSwitcher__Item--Active"> Sign Up</a>
            </div>
            

            <div className="FormCenter">
                <form className="FormFields" onsubmit={this.handleSubmit}> 
                    <div className="FormField">
                        <label className="FormField__Label" htmlFor="name"> Full Name </label>
                        <input type="text" id="name" className="FormField__Input" placeholder="Enter your full name" name="name"/>
                    </div>
                    <div className="FormField">
                        <label className="FormField__Label" htmlFor="Password"> Password </label>
                        <input type="password" id="password" className="FormField__Input" placeholder="Enter your password" name="password"/>
                    </div>
                    <div className="FormField">
                        <label className="FormField__Label" htmlFor="Email"> Email address </label>
                        <input type="Email " id="Email" className="FormField__Input" placeholder="Enter your mail id" name="Email"/>
                    </div>
                    <label className="FormField__CheckboxLabel">
                        <input className="FormField__Checkbox" type="checkbox" name="hasAgreed"/> I agree all statements in <a href="" className="FormField__TermsLink"> terms of services</a>
                    </label>
                    <div className="FormField">
                        <button className="FormField__Button ar-20"> Sign Up </button> <a href= "#" className="FormField__Link"> I'm already memner</a>
                    </div>
                </form>
            </div>
            </div>
            </div>
        );
    }
}
       

export default Login;